﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    int score;
    int highScore;
    public Text ScoreText;
    public Text highScoreText;
    public Text highScorelabel;
    public Text scoreLabel;
    public GameObject gameStartUI;
    private void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        if (PlayerPrefs.HasKey("HighScore"))
        {
            highScore = PlayerPrefs.GetInt("HighScore");
            highScoreText.text = highScore.ToString();
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void GameStart()
    {
        gameStartUI.SetActive(false);
        ScoreText.gameObject.SetActive(true);
        highScoreText.gameObject.SetActive(true);
        scoreLabel.gameObject.SetActive(true);
        highScorelabel.gameObject.SetActive(true);
    }

    public void Restart()
    {
        SceneManager.LoadScene("SampleScene");
    }

    public void ScoreUp()
    {
        score++;
        if (score>highScore)
        {
            highScore = score;
            PlayerPrefs.SetInt("HighScore", highScore);
        }
        ScoreText.text = score.ToString();
        highScoreText.text = highScore.ToString();
    }
}
